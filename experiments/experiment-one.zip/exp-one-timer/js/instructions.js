/*global $, alert, hideElements, divInstructions, buttonNext, trainTrial, condition:true, showDemographics, initTask */
/*jshint multistr: true */

function showIntro() {
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();
    
    divInstructions.show();
    divInstructions.html('<p>This is part of a study being run at the University of Adelaide. By clicking "Next" below you consent to take part in it.</p><p>Details of the study: The principal investigator is Wai Keen Vong (waikeen.vong@adelaide.edu.au). For any questions regarding the ethics of the study, please contact the convenor of the Subcommittee for Human Research in the School of Psychology at the University of Adelaide, Dr Paul Delfabbro (+61) 08 8313 4936. Please direct any questions about this study to Wai Keen Vong. Although any data gained from this study may be published, you will not be identified and your personal details will not be divulged, nor will anything be linked to your Amazon ID. We use your Amazon ID merely to ensure you successfully completed the experiment and are paid. You may withdraw at any time, although you will not be paid unless you complete the study.</p>');

    buttonNext.show();
    buttonNext.click(showDemographics);
}

// displays experiment instructions
function showInstructions() {
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    divInstructions.html('<p>Welcome to your new job! As a new employee your task today will be to learn how to categorize between two different kinds of amoeba known as Bivimias and Lorifens. These two kinds of amoeba evolved from nearby environments and therefore look similar to each other, but they have two very different medicinal uses so it would be helpful to learn how to categorize them better. They both have a circular base and a number of different looking legs. Bivimias and Lorifens vary in the kinds of legs they have, and your goal will be to learn what makes some amoeba Bivimias and other ones Lorifens. However, there is not one simple rule that always gives the best answer and this will be quite difficult!</p>');
    divInstructions.show();

    buttonNext.show();
    buttonNext.click(showInstructionsTwo);
}

function showInstructionsTwo() {
    divInstructions.html('<p>Welcome to your new job! As a new employee your task today will be to learn how to categorize between two different kinds of amoeba known as Bivimias and Lorifens. These two kinds of amoeba evolved from nearby environments and therefore look similar to each other, but they have two very different medicinal uses so it would be helpful to learn how to categorize them better. They both have a circular base and a number of different looking legs. Bivimias and Lorifens vary in the kinds of legs they have, and your goal will be to learn what makes some amoeba Bivimias and other ones Lorifens. However, there is not one simple rule that always gives the best answer and this will be quite difficult!</p><p>Here is an example of one of the amoeba you might encounter today, have a look at how each of the legs look different:</p>');
    divInstructions.show();
    
    divImageSpace.show();

    if(dimensionCondition == 4) {
        drawStimuli('1100', featureDims);
    }
    else if(dimensionCondition == 10) {
        drawStimuli('1100100010', featureDims);
    }
    else {
        drawStimuli('1000100100011010', featureDims);
    }

    buttonNext.show();
    buttonNext.click(showInstructionsThree);
}

function showInstructionsThree() {
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    
    divInstructionsMore.html('<p>On each trial, you will be shown a new amoeba and will be asked to classify whether it is a Bivimia or a Lorifen. After responding, you will receive feedback whether you were right or wrong. Each correct answer gives you 5 base points. Also, if you answer quickly enough, you can earn some bonus points on top of the 5 base points. If you are incorrect you will get no points regardless of how quick you are. So try to be fast as well as accurate! The experiment will have 100 questions, split into five blocks of 20. Altogether, it should take around 15 minutes. Before you begin, we have a few quick questions to make sure you understood these instructions. When you\'re ready, press Next to go on.</p>');
    divInstructionsMore.show();

    buttonNext.show();
    buttonNext.click(showInstructionChecks);
}

function showInstructionChecks() {
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    divInstructions.show();
    divInstructions.html('<p>Here are some questions to check if you have read the instructions correctly. If you do not answer all of the questions correctly, you will be redirected to the instructions page again.</p>');

    var divInstructionChecks = $('#instruction-checks');
    divInstructionChecks.html('<form> \
<label for="question1">What do Bivimias and Lorifens look like?</label><br /> \
<input type="radio" name="question1" value="incorrect" />  Squares with many different symbols <br /> \
<input type="radio" name="question1" value="incorrect" />  Triangles with many different colours <br /> \
<input type="radio" name="question1" value="correct" /> Circles with many different legs <br /><br /> \
<label for="question2">How many points do you get for correct and incorrect responses?</label><br /> \
<input type="radio" name="question2" value="correct" />Correct: 5 points, with bonuses for speed; Incorrect: 0 points<br /> \
<input type="radio" name="question2" value="incorrect" />Correct: 5 points; Incorrect: 0 points<br /> \
<input type="radio" name="question2" value="incorrect" />Correct: 10 points; Incorrect: -10 points<br /> \
<input type="radio" name="question2" value="incorrect" />Correct: 10 points, with bonuses for speed; Incorrect: -10 points<br /><br /> \
<label for="question3">What is the goal of this task?</label><br /> \
<input type="radio" name="question3" value="incorrect" /> Memorize the Bivimias and Lorifens shown <br /> \
<input type="radio" name="question3" value="correct" /> Learn to classify Bivimias and Lorifens <br /> \
<input type="radio" name="question3" value="incorrect" /> Recognize if amoeba shown is one you have seen before or whether it is new <br /> \
</form><br /><br />');
    divInstructionChecks.show();

    buttonNext.show();
    buttonNext.click(validateInstructionChecks);
}

function validateInstructionChecks() {
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    $('form').show();
    var instructionChecks = $('form').serializeArray();

    var ok = true;
    for(var i = 0; i < instructionChecks.length; i++) {
        // check for incorrect responses
        if(instructionChecks[i].value != "correct") {
            ok = false;
            break;
        }

        // check for empty answers
        if(instructionChecks[i].value === "") {
            alert('Please fill out all fields.');
            ok = false;
            break;
        }
    }

    // where this is the number of questions in the instruction check
    if (instructionChecks.length != 3) {
        ok = false;
    }

    if(!ok) {
        alert("You didn't answer all the questions correctly. Please read through the instructions and take the quiz again to continue.");
        showInstructions(); // go back to instruction screen
    }
    else {
        // remove instruction checks form
        $('#instruction-checks').html('');
        initTask(); // start experiment
    }
}

function showInputOptions() {
    /*
     * allow the user to specify which condition they are in
     * as well as which aspect of the experiment to start in
     *
     * this function is particularly useful for debugging and testing
     */

    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    // first present the input options for the experiment (for debugging purposes)
    // allows you to set the experimental conditions instead of randomly assigning them above
    var divInputOptions = $('#input-options');
    divInputOptions.show();
    divInputOptions.html('<h3>Experiment options</h3> \
<p>Number of dimensions</p> \
<select id="dimensionCondition"> \
<option value="4">4</option> \
<option value="16">16</option> \
</select> \
<p>Category structure</p> \
<select id="structureCondition"> \
<option value="predictive60">Predictive 60</option> \
<option value="predictive50">Predictive 50</option> \
</select> \
<p>What section should we start in?</p> \
<select id="section"> \
<option value="intro">Introduction</option> \
<option value="demographics">Demographics</option> \
<option value="instructions">Instructions</option> \
<option value="training">Training</option> \
</select><br /><br />');

    buttonNext.show();
    buttonNext.click(function () {

        // set experimental conditions
        dimensionCondition = $('#dimensionCondition').val();
        structureCondition = $('#structureCondition').val();
        
        // determine which section to start with:
        switch ($('#section').val()) {
        case "intro":
            showIntro();
            break;
        case "demographics":
            showDemographics();
            break;
        case "instructions":
            showInstructions();
            break;
        case "training":
            initTask();
            break;
        }
    });
}
