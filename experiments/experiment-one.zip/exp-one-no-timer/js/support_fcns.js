/*global $, document, divImageSpace, canvas:true, context:true */
/*jshint multistr: true */

function initKinetic() {
    /*
     * init kinetic js
     */

    stage = new Kinetic.Stage({
        container: 'imageSpace',
        width: canvasWidth,
        height: canvasHeight
    });

    layer = new Kinetic.Layer();

    // add stage to layer
    stage.add(layer);
}

function imageClear() {
    /*
     * clear the kinetic js canvas
     */
    
    layer.removeChildren();
    layer.draw();
}

function hideElements() {
    /*
     * hide all buttons, slider, and text
     * clear the canvas and hide it
     */
    
    hideButtons();
    hideCanvas();
    hideText();
    hideTable();
}

function hideText() {
    /*
     * hide all text elements
     */

    $('.text').hide();
}

function hideTable() {
    $('#scoretable').hide();
}

function hideButtons() {
    /*
     * hide all button elements
     * unbind them so any functions previously attached to them are no longer attached
     */

    // hides all buttons
    $(':button').hide();

    // unbinds all buttons
    $(':button').unbind();
}

function hideCanvas() {
    /*
     * clear the canvas and then hide it
     */

    // clear the canvas
    imageClear();

    // hides the canvas drawing
    divImageSpace.hide();
}

function saveData(data) {
    /*
     * write a new row to the database
     *
     * data: a dictionary composed of key, value pairs
     *       containing all the info to write to the database
     *
     * an anonymous function is used because it creates a
     * copy of all information in the data variable, 
     * thus if any other functions change the data object after this function executes
     * then the information written to the database does not change
     */

    (function (d) {
        $.post('submit',  {"content": JSON.stringify(d)});
    })(data);
}
