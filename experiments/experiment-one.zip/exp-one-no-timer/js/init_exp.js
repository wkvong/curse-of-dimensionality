/*global $, document, window, console, alert, start */

// this function runs automatically when the page is loaded
$(document).ready(function () {

    // show an alert if user tries to navigate away from this page
    window.onbeforeunload = function() {
        return "You have not completed the experiment.";
    };

    // load all scripts then begin the experiment
    $.when(
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/offline_testing_tools/jquery-ui-git.js"), // for slider
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/offline_testing_tools/underscore-min.js"), // underscore.js
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/offline_testing_tools/kinetic-v5.1.0.min.js"),
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/support_fcns.js"),
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/exp_logic.js"),
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/instructions.js"),
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/demographics.js"),
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/draw_stimuli.js"),
        $.getScript("/experiments/curse-of-dimensionality/exp-one-no-timer/js/stimuli.js"),

        $.Deferred(function(deferred){
            $(deferred.resolve );
        })
    ).done(function() {
        start();
    });
});
