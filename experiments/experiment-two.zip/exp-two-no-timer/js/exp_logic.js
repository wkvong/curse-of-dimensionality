/*global $, console, initCanvas, hideElements, showInputOptions, showIntro, saveData */

// variables that will store information about the subject and the experiment condition
var subjectID;
var dimensionCondition = [4, 10, 16];
var coherenceCondition = [70, 80, 90];
var demographics = [];

// variables that will store the current trial number and current block number
var currTrial = 1;
var currBlock = 1;
var currBlockTrial = 1;

// kinetic js stuff
var stage;
var layer;

var canvasWidth = 800;
var canvasHeight = 420;

// variables that will store what response subjects select and response time information
var response, base_time, rt;

// variables to keep track of classification accuracy
// var prevBlockPoints = 0;
var currBlockPoints = 0;
var currTrialPoints = 0;
var currBlockScore = 0;
var currTrialScore = 0;

var blockPoints = [];
var blockScore = [];

// variables for the positions and features
var allPositions = _.range(0, 16);
var allDims = _.range(0, 16); 
var featurePositions = []; // positions of all features
var featureDims = []; // underlying feature for each position of all features
var varyingPositions = []; // positions of varying features
var varyingDims = []; // underlying feature for each position in varying features
var fixedPositions; // positions of fixed features
var fixedDims; // underlying feature for each position in fixed features

// variables to keep track of the current stimulus and label
var currStim;
var shuffledStim;
var currLabel;
var predictiveDim;
var predictiveIdx;

// references to divs in the html
var divImageSpace, divInstructions, divInstructionsMore, divStimuli, buttonA, buttonB, buttonNext;

// number of trials overall
var maxTrial = 100;

// number of trials per block
var maxBlockTrial = 20;

// number of blocks
var maxBlock = 5;

// set this to false if you want the user to determine which condition to start in
// set this to true if you want to randomize the condition
var randomizeConditions = true;

var completionCode;

// experimental stimuli
var stimuli;

// in between blocks
var nextBlockPage = false;
var finalBlockPage = false;

function start() {
    /* 
     * start is the first function called (from init_exp.js) when all the files are loaded
     * this function inits many things, such as:
     * a bunch of javascript objects, the canvas we will draw on, and the subject id
     *
     * if randomizeConditions is set to false the user can select which condition they will see
     * and which segment of the experiment they will start in
     * otherwise the condition is randomized and 
     * this function finishes by calling showIntro to begin the experiment
     */

    // init references to elements in html
    initDivReferences();

    // init kinetic js
    initKinetic();

    // generate a subject ID by generating a random number between 1 and 1000000
    subjectID = Math.round(Math.random() * 1000000);

    // if you set this to true, it allow user to select conditions and where to start
    if (!randomizeConditions) {
        showInputOptions();
    } else {
        // randomize experimental conditions
        initCondition();
        showIntro();
    }
}

function initDivReferences() {
    /* 
     * initDivReferences makes a number of jQuery requests to get html elements
     * the results are stored in javascript variables to make accessing them much faster
     * it does not return any value when finished
     *
     * you might want to add new js variables here if you add new html elements
     * to your index.html file. Be sure you declare new ones as is done above for these variables
     */
    
    divImageSpace = $('#imageSpace');
    divInstructions = $('#instructions');
    divInstructionsMore = $('#instructions-more');
    divStimuli = $('#stimuli');
    
    buttonA = $('#a');
    buttonB = $('#b');
    buttonNext = $('#next');
}

function initCondition() {
    /* 
     * initCondition randomly determines which condition to run the current user
     * it does not return any value when finished
     *
     * if you have more than 2 conditions, you might want to add more functionality here
     */

    dimensionCondition =  _.sample(dimensionCondition);
    coherenceCondition = _.sample(coherenceCondition);

    // get positions of varying features 
    if(dimensionCondition == 4) {
        featurePositions = _.shuffle([0, 1, 2, 3]);
    }
    else if(dimensionCondition == 10) {
        featurePositions = _.shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    }
    else if (dimensionCondition == 16) {
        featurePositions = _.shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
    }
    
    // randomly sample features to use
    featureDims = _.sample(allPositions, allPositions.length);

    // get predictive feature from shuffled features, should be where feature 0 is
    predictiveIdx = featurePositions.indexOf(0);
    predictiveDim = featureDims[predictiveIdx];

    // generate stimuli for experiment
    experiment_data = generateStimuli(coherenceCondition, dimensionCondition);
    stims = experiment_data.stims;
    labels = experiment_data.labels;

    // generate random completion code here
    completionCode = _.sample(_.range(10000, 99999));
}

function initTask() {
    /* 
     * initTask does all the configuration before beginning training and testing
     * when done, start training by calling trainTrial
     */
    
    // change text value of response buttons depending on colour condition
    buttonA.prop('value', 'Bivimia');
    buttonB.prop('value', 'Lorifen');
    
    // start the training
    startTraining();
}

function startTraining() {
    // page to display before the first training block

    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    // display training trial instructions
    divInstructions.html('You have correctly answered all of the questions. When you are ready to begin the experiment, please press the Next button.'); 
    divInstructions.show();

    buttonNext.show();
    buttonNext.click(trainTrial);
}

function startBlock() {
    // page to display in between training blocks, does not appear before the first block
    
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    nextBlockPage = true;
    
    // display training trial instructions
    if(blockScore[currBlock - 2] < 10) {
        divInstructions.html('You have finished the current block of training, your current score is displayed below. Keep trying, this task is quite difficult but you will be paid upon completion! When you are ready to continue, please press the Next button.');
    }
    else {
        divInstructions.html('You have finished the current block of training, your current score is displayed below. Keep up the good work and remember you will be paid upon completion! When you are ready to continue, please press the Next button.');
    }
    divInstructions.show();

    displayBlockScore();

    buttonNext.show();
    buttonNext.click(trainTrial);
}

function displayBlockScore() {
    var scorehtml = '<table width=\'100%\'><col style=\'width:33%\'><col style=\'width:33%\'><col style=\'width:33%\'>'

    scorehtml += '<thead><tr><td>Block</td><td>Correct</td><td>Points</td></tr></thead>'
    
    for(var i = 0; i < blockScore.length; i++) {
        var blockScoreProp = Math.round(blockScore[i]/maxBlockTrial * 100 * 10)/10;
        scorehtml += '<tr><td>' + (i + 1) + '</td><td>' + blockScoreProp + '%</td><td>' + blockPoints[i] + '</td>'
    }

    scorehtml += '</table>'

    $('#scoretable').html(scorehtml);
    $('#scoretable').show();
}

function shuffleStim(currStim) {
    // returns a shuffled version of the stimuli
    var shuffledStim = '';

    for(var i = 0; i < currStim.length; i++) {
        shuffledStim += currStim[featurePositions[i]];
    }

    return(shuffledStim);
}

function trainTrial() {
    /* 
     * display a training trial in which a colored line is shown on the screen
     * and subjects are asked to press next when done studying it
     *
     * which stimuli to display from trainingTrialStimuli is determined
     * by the current block (currentBlock) and current trial number (currTrial)
     *
     * after each Next click, checks if the correct number of training trials have been shown
     * if so, proceed to test trials
     * otherwise, show another training trial
     */

    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    nextBlockPage = false;
    
    // display training trial instructions
    divInstructions.show();
    divInstructions.html('Is this a bivimia or a lorifen?');
    
    // draw training stimuli in canvas
    divImageSpace.show();
    
    // show score on the screen
    drawScore(currBlockPoints);

    // show prop correct.
    drawCorrect(currBlockScore, currBlockTrial) ;
    
    // show trial/block on screen
    drawTrial(currTrial, maxTrial);
    drawBlock(currBlock, maxBlock);
    
    // draw with delay to break up feedback from prev. stim
    setTimeout(function() {
        base_time = new Date().getTime();

        currStim = stims[currTrial - 1]; // get current stim
        currLabel = labels[currTrial - 1]; // get current label
        shuffledStim = shuffleStim(currStim); // shuffle stimuli

        // draw stimuli
        drawStimuli(shuffledStim, featureDims);

        // initialize empty response
        response = -1;
        
        // show response buttons
        buttonA.show();
        buttonB.show();

        buttonA.click(function () {response = 0; saveTrial();});
        buttonB.click(function () {response = 1; saveTrial();});
    }, 1000); // TODO: move back to 1000
}

function saveTrial() {
    /*
     * saveTrial builds up an object (exp_data) containing all of the
     * data from the current trial to save to the database
     * 
     * all of the information to save to the database needs to be added to exp_data. 
     * exp_data is a javascript dictionary, which consists of [key, value] pairs
     * To add a new pair to exp_data, do:
     * exp_data.KEY = VALUE;
     * you can see multiple examples of how this is done below
     *
     * when exp_data is completely built, it is passed as a paramter to saveData
     * which actually writes the information to the database on Google App Engine
     * 
     * after writing the data, this function calls selectNextTrial to determine
     * what the next type of trial should be
     *
     * to see how to retrieve all data, please look at the documentation in README.md
     */
    
    rt = new Date().getTime() - base_time;

    // all of the data from this trial will go into this object
    var exp_data = {};

    // add demographics data to trial output
    for (var i = 0; i < demographics.length; i++) {
        exp_data[demographics[i].name] = demographics[i].value;
    }

    // fix type of age if it exists (from demographics)
    if ("age" in exp_data)
        exp_data.age = parseInt(exp_data.age, 10);

    // add trial data to trial output
    exp_data.experiment = "exp_two_no_timer";
    exp_data.subject_ID = subjectID;
    exp_data.dimension_condition = dimensionCondition;
    exp_data.coherence_condition = coherenceCondition;
    exp_data.predictive_dim = predictiveDim;
    exp_data.predictive_idx = predictiveIdx;
    exp_data.feature_positions = featurePositions.toString().split(",").join("_");
    exp_data.feature_dims = featureDims.toString().split(",").join("_");
    exp_data.trial = currTrial;
    exp_data.block = currBlock;
    exp_data.block_trial = currBlockTrial;

    exp_data.stim = currStim.toString().split(",").join(""); // save stim as a string instead of array
    exp_data.shuffled_stim = shuffledStim;
    exp_data.label = currLabel;
    exp_data.rt = rt;
    exp_data.button_value = response;
    exp_data.completion_code = completionCode;

    // print the data to console for debugging
    console.log(exp_data);

    // save trial data
    // saveData(exp_data);

    // show feedback on current trial
    showFeedback();
}

function showFeedback() {
    // calculate points for this trial
    currTrialPoints = 5;

    // display feedback on the screen
    if(response == currLabel) {
        currBlockPoints = currBlockPoints + currTrialPoints; // add points
        currBlockScore = currBlockScore + 1; // increment number correct by 1
        
        if(currLabel == '0') {
            divInstructions.html('<font color=\'green\'>Correct!</font> This is a <font color=\'blue\'>Bivimia</font>'); 
        }
        else {
            divInstructions.html('<font color=\'green\'>Correct!</font> This is a <font color=\'purple\'>Lorifen</font>');
        }
    }
    else {
        if(currLabel == '0') {
            divInstructions.html('<font color=\'red\'>Incorrect.</font> This is a <font color=\'blue\'>Bivimia</font>'); 
        }
        else {
            divInstructions.html('<font color=\'red\'>Incorrect.</font> This is a <font color=\'purple\'>Lorifen</font>'); 
        }
    }

    // add feedback animation
    if(currLabel == '0') {
        drawBivimiaFeedback();
    }
    else {
        drawLorifenFeedback();
    }
    
    divInstructions.show();

    buttonA.hide();
    buttonB.hide();

    setTimeout(function() {
        selectNextTrial();
    }, 3000); // TODO: move back to 3000
}

function selectNextTrial () {
    /*
     * selectNextTrial determines based on the currTrial and currBlock variables
     * what the next type of trial should be or if the experiment is done
     * 
     * the appropriate function is called next
     */

    // determine which section to go to next

    // increment trial
    currTrial++;
    currBlockTrial++;
    
    if(currBlockTrial <= maxBlockTrial) {
        trainTrial(); // proceed to next training example
    }
    else {
        // increment block 
        currBlock++;
        blockPoints[currBlock - 2] = currBlockPoints; // store prev block score
        blockScore[currBlock - 2] = currBlockScore;

        if(currBlock <= maxBlock) {
            currBlockTrial = 1; // reset trial counter
            currBlockPoints = 0; // reset score
            currBlockScore = 0;
            startBlock(); // next training block
        }
        else {
            finalBlock(); // display summary scores
        }
    }
}

function finalBlock() {
    // page to display in between training blocks, does not appear before the first block
    
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    finalBlockPage = true;
    
    // display final score
    divInstructions.html('Congratulations on finishing the experiment! Here is a summary of your results for each block. Click the Next button to receive your completion code.');
    
    divInstructions.show();

    displayBlockScore();

    buttonNext.show();
    buttonNext.click(finishExperiment);
}

function finishExperiment() {
    /* 
     * finishExperiment is called when all trials are complete and subjects are done
     * removes everything from the screen and thanks the subject
     */
    
    // remove all elements from the screen
    // reset all buttons so they do not have any functions bound to them
    hideElements();

    divInstructions.html('<p>You have completed the experiment! If you are doing the experiment from Mechanical Turk, please enter the code:</p> <p><span id="completion-code">01925</span></p> <p>to complete the HIT. If you are interested in learning more about this experiment, click <a href="debrief" target="_blank">here</a> to read a debriefing about the study you just completed (the link will open in a new tab so you won\'t lose your code to complete this HIT).</p>');
    $('#completion-code').html(completionCode); // set completion code here with fallback code 01925
    divInstructions.show();
}

function runExperiment() {
        // function to automatically run through experiment

    // pass ethics
    $('#next').click();

    // fill in demographics
    $('#age').val(27);
    $('#male').click();
    $('#next').click();

    // click through instructions
    $('#next').click();
    $('#next').click();
    $('#next').click();

    // answer instruction checks
    $('#question1-correct').click();
    $('#question2-correct').click();
    $('#question3-correct').click();
    $('#next').click()

    // begin experiment
    $('#next').click()

    // keep pressing a until next page
    var interval = setInterval(function() {
        if(nextBlockPage) {
            $('#next').click();
        }
        if($('#a').is(":visible")) {
            $('#a').click();
        }
        if(finalBlockPage) {
            $('#next').click();
            clearInterval(interval)
        }
    }, 100)
}
