function generateStimuli(coherenceCondition, dimensionCondition) {
    // function to generate stimuli
    
    // initialize variables
    var stims = [];
    var labels = [];
    var theta_0 = [];
    var theta_1 = [];

    // experiment probabilities
    var predictive_prob = 0.9;
    var intermediate_prob = 0.7;
    var random_prob = 0.5
    var prob;
    
    if(coherenceCondition == 70) {
        prob = 0.7;
    }
    else if(coherenceCondition == 80) {
        prob = 0.8;
    }
    else if(coherenceCondition == 90){
        prob = 0.9;
    }

    theta_0 = _.range(dimensionCondition).map(function() { return(prob) });
    theta_1 = _.map(theta_0, function(i) { return(1 - i) })
    
    // randomly sample labels for each trial
    for(var i = 0; i < maxTrial; i++) {
        labels[i] = _.sample([0, 1]);
        
        r = _.range(dimensionCondition).map(function() { return(Math.random()) }); // generate vector of random numbers
        
        // generate stimulus values for varying features based on coherence condition
        if(labels[i] == 0) {
            stims[i] = _.map(r, function(i, index) { return(i > theta_0[index] | 0) } )
        }
        else if(labels[i] == 1) {
            stims[i] = _.map(r, function(i, index) { return(i > theta_1[index] | 0) } )
        }

        // // add fixed feature values
        // stims[i] = stims[i].concat(fixedFeatureValues);
    }

    return({stims:stims, labels:labels})
}

function checkStimuli(experiment_data) {
    // function to check if generateStimuli produces correct probabilities
    
    theta_0 = [];
    stims = experiment_data.stims;
    labels = experiment_data.labels;

    // initialize theta_0 to be 0
    for(var i = 0; i < stims[0].length; i++) {
        theta_0[i] = 0;
    }
    
    // count instances where feature value matches label for each feature
    for(var i = 0; i < stims.length; i++) {
        curr_stim = stims[i];
        curr_label = labels[i];

        for(var j = 0; j < curr_stim.length; j++) {
            if(curr_stim[j] == curr_label) {
                theta_0[j] = theta_0[j] + 1;
            }
        }
    }

    // divide by number of stimuli
    for(var i = 0; i < theta_0.length; i++) {
        theta_0[i] = theta_0[i]/stims.length;
    }

    return(theta_0)
}
