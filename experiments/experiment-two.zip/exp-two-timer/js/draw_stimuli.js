var lineLength = 200;
var lineWidth = 3;

var countdown_anim;

function drawTrial(currTrial, maxTrial) {
    var score = new Kinetic.Text({
        x: 20,
        y: 20,
        text: 'Question: ' + currTrial + '/' + maxTrial,
        fontSize: 20,
        fontFamily: 'Times New Roman',
        fill: 'black'
    });

    layer.add(score);
    layer.draw();
}

function drawBlock(currBlock, maxBlock) {
    var score = new Kinetic.Text({
        x: 20,
        y: 50,
        text: 'Block: ' + currBlock + '/' + maxBlock,
        fontSize: 20,
        fontFamily: 'Times New Roman',
        fill: 'black'
    });

    layer.add(score);
    layer.draw();
}

function drawCorrect(correct, trial) {
    if((trial - 1) == 0) {
        trial = 1;
    }
    else {
        trial = trial - 1; // adjust based on prev trial.
    }

    var prop = correct * 100 / trial;
    var rounded_prop = Math.round(prop * 10)/10;
    
    var prop = new Kinetic.Text({
        x: 20,
        y: 100,
        text: 'Correct: ' + rounded_prop + '%',
        fontSize: 20,
        fontFamily: 'Times New Roman',
        fill: 'black'
    });

    layer.add(prop);
    layer.draw();
}

function drawScore(points) {
    var score = new Kinetic.Text({
        x: 20,
        y: 130,
        text: 'Score: ' + points,
        fontSize: 20,
        fontFamily: 'Times New Roman',
        fill: 'black'
    });

    layer.add(score);
    layer.draw();
}

function drawTimer() {
    var timer = new Kinetic.Rect({
        x: 720,
        y: canvasHeight/2 - 125,
        width: 20,
        height: 250,
        fill: 'white',
        stroke: 'black',
        strokeWidth: 3
    });

    layer.add(timer);
    layer.draw();

    var countdown = new Kinetic.Rect({
        x: 720,
        y: canvasHeight/2 + 125,
        width: 20,
        height: 250,
        fill: 'green'
    });
    
    var period = 10000;
    var scale = -1;
    
    countdown_anim = new Kinetic.Animation(function(frame) {
        if(scale < 0) {
            scale = frame.time/period + 0.001 - 1;
        }
        else {
            countdown_anim.stop();
        }

        // scale x and y
        countdown.scale({x:1, y:scale});
    }, layer);

    layer.add(countdown);
    layer.draw();
    
    countdown_anim.start();
}

function drawStimuli(currStim, featureDims) {
    var transformedStim = [];
    
    // transforms the current stimuli array into a 0 to 31 mapping for all 32 possible features
    for(var i = 0; i < currStim.length; i++) {
        // need to parse currStim as it is a string
        transformedStim[i] = featureDims[i] * 2 + parseInt(currStim[i])
    }

    // draw features
    for(var i = 0; i < transformedStim.length; i++) {
        var angle;
        
        if(currStim.length == 4) {
            angle = i * 360 / transformedStim.length + 45;
        }
        else {
            angle = i * 360 / transformedStim.length;
        }

        // determine which features to draw
        switch(transformedStim[i]) {
        case 0:
            drawFeature1a(angle);
            break;
        case 1:
            drawFeature1b(angle);
            break;
        case 2:
            drawFeature2a(angle);
            break;
        case 3:
            drawFeature2b(angle);
            break;
        case 4:
            drawFeature3a(angle);
            break;
        case 5:
            drawFeature3b(angle);
            break;
        case 6:
            drawFeature4a(angle);
            break;
        case 7:
            drawFeature4b(angle);
            break;
        case 8:
            drawFeature5a(angle);
            break;
        case 9:
            drawFeature5b(angle);
            break;
        case 10:
            drawFeature6a(angle);
            break;
        case 11:
            drawFeature6b(angle);
            break;
        case 12:
            drawFeature7a(angle);
            break;
        case 13:
            drawFeature7b(angle);
            break;
        case 14:
            drawFeature8a(angle);
            break;
        case 15:
            drawFeature8b(angle);
            break;
        case 16:
            drawFeature9a(angle);
            break;
        case 17:
            drawFeature9b(angle);
            break;
        case 18:
            drawFeature10a(angle);
            break;
        case 19:
            drawFeature10b(angle);
            break;
        case 20:
            drawFeature11a(angle);
            break;
        case 21:
            drawFeature11b(angle);
            break;
        case 22:
            drawFeature12a(angle);
            break;
        case 23:
            drawFeature12b(angle);
            break;
        case 24:
            drawFeature13a(angle);
            break;
        case 25:
            drawFeature13b(angle);
            break;
        case 26:
            drawFeature14a(angle);
            break;
        case 27:
            drawFeature14b(angle);
            break;
        case 28:
            drawFeature15a(angle);
            break;
        case 29:
            drawFeature15b(angle);
            break;
        case 30:
            drawFeature16a(angle);
            break;
        case 31:
            drawFeature16b(angle);
            break;
        default:
            break;
        }
    }

    // draw base of object
    drawBase();
}

function drawBase() {
    var base = new Kinetic.Circle({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: 'base',
        radius: 50,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    layer.add(base);
    layer.draw();
}

function drawBivimiaFeedback() {
    countdown_anim.stop();
    
    var bivimia = new Kinetic.Circle({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: 'base',
        radius: 50,
        fill: 'blue',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    layer.add(bivimia);
    layer.draw();

    var period = 2000;
    var scale = 0;
    
    var anim = new Kinetic.Animation(function(frame) {
        if (scale < 0.99) {
            scale = Math.sin(frame.time * 2 * Math.PI / period) + 0.001;
        }
        else {
            scale = 1;
        }
        
        // scale x and y
        bivimia.scale({x:scale,y:scale});
    }, layer);

    anim.start();
}

function drawLorifenFeedback() {
    countdown_anim.stop();
    
    var lorifen = new Kinetic.Circle({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: 'base',
        radius: 50,
        fill: 'purple',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    layer.add(lorifen);
    layer.draw();

    var period = 2000;
    var scale = 0;
    
    var anim = new Kinetic.Animation(function(frame) {
        if (scale < 0.99) {
            scale = Math.sin(frame.time * 2 * Math.PI / period) + 0.001;
        }
        else {
            scale = 1;
        }
        
        // scale x and y
        lorifen.scale({x:scale,y:scale});
    }, layer);

    anim.start();
}

function drawFeature1a(angle) {
    var feature = new Kinetic.Group({
        name: '1a',
        x: canvasWidth/2,
        y: canvasHeight/2,
    });

    var line = new Kinetic.Line({
        points: [0, 0, 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth,
    });

    var circle = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 20,
        radius: 20,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(circle);
    feature.rotate(angle);
    
    layer.add(feature);
    layer.draw();
}


function drawFeature1b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '1b',
    });

    var line = new Kinetic.Line({
        points: [0, 0, 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth,
    });

    var circle = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 20,
        radius: 20,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    })

    var innerCircle = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 20,
        radius: 3,
        fill: 'black',
        stroke: 'black',
        strokeWidth: lineWidth
    })

    feature.add(line);
    feature.add(circle);
    feature.add(innerCircle);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature2a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '2a',
    });

    var line = new Kinetic.Line({
        points: [0, 0, 0, -lineLength + 40, 10, -lineLength + 40, 10, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    feature.add(line);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw()
}

function drawFeature2b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '2b',
    });

    var line = new Kinetic.Line({
        points: [0, 0, 0, -lineLength, 10, -lineLength, 10, -lineLength + 40],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    feature.add(line);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw()
}

function drawFeature3a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '3a',
    });

    var line = new Kinetic.Line({
        points: [0, 0, 0, -lineLength + 40, -20, -lineLength, 0, -lineLength + 40, 20, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    feature.add(line);
    feature.rotate(angle);
    
    layer.add(feature);
    layer.draw()
}

function drawFeature3b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '3b',
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 40,
                 -20, -lineLength,
                 0, -lineLength + 40,
                 0, -lineLength,
                 0, -lineLength + 40,
                 20, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    feature.add(line);
    feature.rotate(angle);
    
    layer.add(feature);
    layer.draw()
}

function drawFeature4a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '4a',
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 80,
                 15, -lineLength + 80,
                 15, -lineLength + 60,
                 0, -lineLength + 60,
                 0, -lineLength + 40,
                 15, -lineLength + 40,
                 15, -lineLength + 20,
                 0, -lineLength + 20,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.rotate(angle);
    
    layer.add(feature);
    layer.draw()
}

function drawFeature4b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '4b',
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 80,
                 15, -lineLength + 80,
                 15, -lineLength + 70,
                 0, -lineLength + 70,
                 0, -lineLength + 60,
                 15, -lineLength + 60,
                 15, -lineLength + 50,
                 0, -lineLength + 50,
                 0, -lineLength + 40,
                 15, -lineLength + 40,
                 15, -lineLength + 30,
                 0, -lineLength + 30,
                 0, -lineLength + 20,
                 15, -lineLength + 20,
                 15, -lineLength + 10,
                 0, -lineLength + 10,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.rotate(angle);
    
    layer.add(feature);
    layer.draw()
}

function drawFeature5a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '5a'
    })

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 50,
                 -15, -lineLength + 40,
                 15, -lineLength + 25,
                 -15, -lineLength + 10,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature5b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '5b'
    })

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 80,
                 -15, -lineLength + 70, 
                 15, -lineLength + 55,
                 -15, -lineLength + 40,
                 15, -lineLength + 25,
                 -15, -lineLength + 10,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();    
}

function drawFeature6a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '6a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle1 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 15,
        radius: 15,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle2 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 60,
        radius: 15,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle3 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 105,
        radius: 15,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(circle1);
    feature.add(circle2);
    feature.add(circle3);
    feature.rotate(angle)

    layer.add(feature);
    layer.draw();
}

function drawFeature6b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '6b'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle1 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 15,
        radius: 15,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle2 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 60,
        radius: 15,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle3 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 105,
        radius: 15,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle4 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 15,
        radius: 7,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle5 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 60,
        radius: 7,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle6 = new Kinetic.Circle({
        x: 0,
        y: -lineLength + 105,
        radius: 7,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(circle1);
    feature.add(circle2);
    feature.add(circle3);
    feature.add(circle4);
    feature.add(circle5);
    feature.add(circle6);
    feature.rotate(angle)

    layer.add(feature);
    layer.draw();
}

function drawFeature7a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '7a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 120,
                 -15, -lineLength + 80,
                 0, -lineLength + 80,
                 -15, -lineLength + 40,
                 0, -lineLength + 40,
                 -15, -lineLength,
                 15, -lineLength,
                 0, -lineLength + 40,
                 15, -lineLength + 40,
                 0, -lineLength + 80,
                 15, -lineLength + 80,
                 0, -lineLength + 120],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature7b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '7a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 120,
                 -15, -lineLength + 80,
                 0, -lineLength + 80,
                 -15, -lineLength + 40,
                 0, -lineLength + 40,
                 -15, -lineLength,
                 15, -lineLength,
                 0, -lineLength + 40,
                 15, -lineLength + 40,
                 0, -lineLength + 80,
                 15, -lineLength + 80,
                 0, -lineLength + 120],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line2 = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })
    
    feature.add(line);
    feature.add(line2);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature8a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '8a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 40],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var diamond = new Kinetic.Line({
        points: [0, -lineLength,
                 -20, -lineLength + 20,
                 0, -lineLength + 40,
                 20, -lineLength + 20,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(diamond);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature8b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '8b'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 40],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var diamond = new Kinetic.Line({
        points: [0, -lineLength,
                 -20, -lineLength + 20,
                 0, -lineLength + 40,
                 20, -lineLength + 20,
                 0, -lineLength,
                 0, -lineLength + 40,
                 20, -lineLength + 20,
                 -20, -lineLength + 20],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(diamond);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature9a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '9a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line2 = new Kinetic.Line({
        points: [-15, -lineLength + 100,
                 15, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature9b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '9a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line2 = new Kinetic.Line({
        points: [-15, -lineLength + 100,
                 15, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line3 = new Kinetic.Line({
        points: [15, -lineLength + 100,
                 -15, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2);
    feature.add(line3);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature10a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '10a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line2 = new Kinetic.Line({
        points: [-20, -lineLength,
                 20, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line3 = new Kinetic.Line({
        points: [-20, -lineLength + 40,
                 20, -lineLength + 40],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line4 = new Kinetic.Line({
        points: [-20, -lineLength + 80,
                 20, -lineLength + 80],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2);
    feature.add(line3);
    feature.add(line4);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature10b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '10a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line2 = new Kinetic.Line({
        points: [-20, -lineLength,
                 20, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line3 = new Kinetic.Line({
        points: [-20, -lineLength + 20,
                 20, -lineLength + 20],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line4 = new Kinetic.Line({
        points: [-20, -lineLength + 40,
                 20, -lineLength + 40],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line5 = new Kinetic.Line({
        points: [-20, -lineLength + 60,
                 20, -lineLength + 60],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line6 = new Kinetic.Line({
        points: [-20, -lineLength + 80,
                 20, -lineLength + 80],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2);
    feature.add(line3);
    feature.add(line4);
    feature.add(line5);
    feature.add(line6);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();    
}

function drawFeature11a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '11a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 80],
        stroke: 'black',
        strokeWidth: lineWidth
    });
    
    var line2 = new Kinetic.Line({
        points: [0, -lineLength,
                 20, -lineLength + 20,
                 20, -lineLength + 60,
                 0, -lineLength + 80,
                 -20, -lineLength + 60,
                 -20, -lineLength + 20,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature11b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '11b'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 80],
        stroke: 'black',
        strokeWidth: lineWidth
    });
    
    var line2 = new Kinetic.Line({
        points: [0, -lineLength,
                 20, -lineLength + 20,
                 20, -lineLength + 60,
                 0, -lineLength + 80,
                 -20, -lineLength + 60,
                 -20, -lineLength + 20,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line3 = new Kinetic.Line({
        points: [0, -lineLength + 10,
                 12, -lineLength + 22,
                 12, -lineLength + 58,
                 0, -lineLength + 70,
                 -12, -lineLength + 58,
                 -12, -lineLength + 22,
                 0, -lineLength + 10],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2);
    feature.add(line3);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature12a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '12a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 10],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle1 = new Kinetic.Circle({
        x: -10,
        y: -lineLength + 10,
        radius: 2,
        fill: 'black',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle2 = new Kinetic.Circle({
        x: -10,
        y: -lineLength + 50,
        radius: 2,
        fill: 'black',
        stroke: 'black',
        strokeWidth: lineWidth
    });
    var circle3 = new Kinetic.Circle({
        x: 10,
        y: -lineLength + 10,
        radius: 2,
        fill: 'black',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle4 = new Kinetic.Circle({
        x: 10,
        y: -lineLength + 50,
        radius: 2,
        fill: 'black',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(circle1);
    feature.add(circle2);
    feature.add(circle3);
    feature.add(circle4);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature12b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '12b'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 10],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle1 = new Kinetic.Circle({
        x: -10,
        y: -lineLength + 10,
        radius: 8,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle2 = new Kinetic.Circle({
        x: -10,
        y: -lineLength + 50,
        radius: 8,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });
    var circle3 = new Kinetic.Circle({
        x: 10,
        y: -lineLength + 10,
        radius: 8,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var circle4 = new Kinetic.Circle({
        x: 10,
        y: -lineLength + 50,
        radius: 8,
        fill: 'white',
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(circle1);
    feature.add(circle2);
    feature.add(circle3);
    feature.add(circle4);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();   
}

function drawFeature13a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '13a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });
    
    var arc = new Kinetic.Arc({
        innerRadius: 70,
        outerRadius: 70,
        stroke: 'black',
        strokeWidth: lineWidth,
        angle: 90,
        rotationDeg: -45,
        x: -75,
        y: -lineLength + 50
    });

    var arc2 = new Kinetic.Arc({
        innerRadius: 70,
        outerRadius: 70,
        stroke: 'black',
        strokeWidth: lineWidth,
        angle: 90,
        rotationDeg: 135,
        x: 75,
        y: -lineLength + 50
    });
    
    feature.add(line);
    feature.add(arc);
    feature.add(arc2);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature13b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '13b'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });
    
    var arc = new Kinetic.Arc({
        innerRadius: 70,
        outerRadius: 70,
        stroke: 'black',
        strokeWidth: lineWidth,
        angle: 90,
        rotationDeg: -45,
        x: -50,
        y: -lineLength + 50
    });

    var arc2 = new Kinetic.Arc({
        innerRadius: 70,
        outerRadius: 70,
        stroke: 'black',
        strokeWidth: lineWidth,
        angle: 90,
        rotationDeg: 135,
        x: 50,
        y: -lineLength + 50
    });
    
    feature.add(line);
    feature.add(arc);
    feature.add(arc2);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();    
}

function drawFeature14a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '14a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line2 = new Kinetic.Line({
        points: [-20, -lineLength + 20,
                 0, -lineLength,
                 20, -lineLength + 20],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2)
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature14b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '14b'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 40],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    var line2 = new Kinetic.Line({
        points: [-20, -lineLength + 20,
                 0, -lineLength,
                 20, -lineLength + 20,
                 20, -lineLength + 60,
                 0, -lineLength + 40,
                 -20, -lineLength + 60,
                 -20, -lineLength + 20],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.add(line2)
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature15a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '15a'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 120,
                 -15, -lineLength + 100,
                 0, -lineLength + 80,
                 -15, -lineLength + 60,
                 0, -lineLength + 40,
                 -15, -lineLength + 20,
                 0, -lineLength,
                 15, -lineLength + 20,
                 0, -lineLength + 40,
                 15, -lineLength + 60,
                 0, -lineLength + 80,
                 15, -lineLength + 100,
                 0, -lineLength + 120],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature15b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '15b'
    });

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength + 120,
                 -15, -lineLength + 100,
                 15, -lineLength + 100,
                 -15, -lineLength + 60,
                 15, -lineLength + 60,
                 -15, -lineLength + 20,
                 15, -lineLength + 20,
                 0, -lineLength,
                 -15, -lineLength + 20,
                 15, -lineLength + 20,
                 -15, -lineLength + 60,
                 15, -lineLength + 60,
                 -15, -lineLength + 100,
                 15, -lineLength + 100,
                 0, -lineLength + 120],
        stroke: 'black',
        strokeWidth: lineWidth
    });

    feature.add(line);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();    
}

function drawFeature16a(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '16a'
    })

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    var line2 = new Kinetic.Line({
        points: [-10, -lineLength + 80,
                 -10, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    var line3 = new Kinetic.Line({
        points: [10, -lineLength + 80,
                 10, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    feature.add(line);
    feature.add(line2);
    feature.add(line3);
    feature.rotate(angle);

    layer.add(feature);
    layer.draw();
}

function drawFeature16b(angle) {
    var feature = new Kinetic.Group({
        x: canvasWidth/2,
        y: canvasHeight/2,
        name: '16b'
    })

    var line = new Kinetic.Line({
        points: [0, 0,
                 0, -lineLength],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    var line2 = new Kinetic.Line({
        points: [-10, -lineLength + 80,
                 -10, -lineLength,
                 10, -lineLength,
                 10, -lineLength + 80,
                 -10, -lineLength + 80],
        stroke: 'black',
        strokeWidth: lineWidth
    })

    feature.add(line);
    feature.add(line2);
    feature.rotate(angle);
    
    layer.add(feature);
    layer.draw();    
}
